package InterViewR.domain.security;

public enum Role {
    Admin,
    User
}
