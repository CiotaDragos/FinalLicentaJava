package InterViewR.services.security;

public interface InputService {

}
